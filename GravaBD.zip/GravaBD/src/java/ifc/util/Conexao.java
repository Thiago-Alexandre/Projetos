
package ifc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
   private static Connection conexao;
   private static final String URL_CONEXAO = "jdbc:postgresql://localhost/agenda";
   private static final String USUARIO = "postgres";
   private static final String SENHA = "postgres";
   
  public static Connection getConexao(){
      if(conexao == null){
          try {
              Class.forName("org.postgresql.Driver");
              conexao = DriverManager.getConnection(URL_CONEXAO, USUARIO, SENHA);
          } catch (ClassNotFoundException | SQLException ex) {
              System.err.println("Erro de conexão: " + ex.getMessage());
          }
      }
      return conexao;
  }
  
  public static void fecharConexao(){
    if(conexao != null){
        try {
            conexao.close();
            conexao = null;
        } catch (SQLException ex) {
            System.err.println("Erro de conexão: " + ex.getMessage());
        }
    }  
  }
}
