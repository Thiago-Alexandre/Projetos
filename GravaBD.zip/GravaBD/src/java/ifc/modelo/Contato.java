/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifc.modelo;

import ifc.util.Conexao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class Contato {
    private int id;
    private String nome;
    private String fone;
    private String login;
    private String Senha;

    public boolean salvar(){
       String sql = "insert into contatos(nome, fone, login, senha) values (?, ?,?,?)";
        try {
            PreparedStatement stm = Conexao.getConexao().prepareStatement(sql);
            stm.setString(1, this.getNome());
            stm.setString(2, this.getFone());
            stm.setString(3, this.getLogin());
            stm.setString(4, this.getSenha());
            stm.execute();
        } catch (SQLException ex) {
            System.err.println("Erro: " + ex.getMessage());
            return false;
        } 
        finally {
            Conexao.fecharConexao();
        }
        return true; 
    }
    
    public List<Contato> listar(){
        List<Contato> lista = new ArrayList<>();
        try {
            PreparedStatement stm
                    = Conexao.getConexao()
                            .prepareStatement("select * from contatos");
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                lista.add(new Contato(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("fone"),
                        rs.getString("login"),
                        rs.getString("senha")));
            }
        } catch (SQLException ex) {
            System.err.println("Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao();
        }
        return lista;   
    }

    public Contato(int id, String nome, String fone, String login, String Senha) {
        this.id = id;
        this.nome = nome;
        this.fone = fone;
        this.login = login;
        this.Senha = Senha;
    }

    public Contato() {
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
   
   
}
